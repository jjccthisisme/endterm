import '../models/car.dart';

List<Car> carList = [
  Car(name: "Model S", brand: "Tesla", price: 79999, imageUrl: "https://link_to_tesla_image.com"),
  Car(name: "Mustang", brand: "Ford", price: 55999, imageUrl: "https://link_to_mustang_image.com"),
  // Add more cars here
];

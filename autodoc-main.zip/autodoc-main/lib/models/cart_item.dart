class CartItem {
  final String name;
  final int quantity;

  CartItem({required this.name, this.quantity = 1});
}
